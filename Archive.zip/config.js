module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '1414890215555455',
        clientSecret: '97105e52c56f3e20193be25c542a07d2'
    }
}